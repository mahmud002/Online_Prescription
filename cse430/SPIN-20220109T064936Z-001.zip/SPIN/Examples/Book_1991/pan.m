#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* PROC :init: */
	case 3: // STATE 1 - p101.pml:16 - [(run A())] (0:0:0 - 1)
		IfNotBlocked
		reached[2][1] = 1;
		if (!(addproc(II, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 2 - p101.pml:16 - [(run B())] (0:0:0 - 1)
		IfNotBlocked
		reached[2][2] = 1;
		if (!(addproc(II, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 5: // STATE 4 - p101.pml:17 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[2][4] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC B */
	case 6: // STATE 1 - p101.pml:13 - [name?33,state] (0:0:2 - 1)
		reached[1][1] = 1;
		if (boq != now.name) continue;
		if (q_len(now.name) == 0) continue;

		XX=1;
		if (33 != qrecv(now.name, 0, 0, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state);
		;
		((P1 *)_this)->state = qrecv(now.name, XX-1, 1, 1);
#ifdef VAR_RANGES
		logval("B:state", ((int)((P1 *)_this)->state));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.name);
			sprintf(simtmp, "%d", 33); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((int)((P1 *)_this)->state)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(now.name))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		if (TstOnly) return 1; /* TT */
		/* dead 2: state */  (trpt+1)->bup.ovals[1] = ((P1 *)_this)->state;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state = 0;
		_m = 4; goto P999; /* 0 */
	case 7: // STATE 2 - p101.pml:14 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC A */
	case 8: // STATE 1 - p101.pml:8 - [name!33,124] (0:0:0 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		if (q_len(now.name))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.name);
		sprintf(simtmp, "%d", 33); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 124); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.name, 0, 33, 124, 2);
		{ boq = now.name; };
		_m = 2; goto P999; /* 0 */
	case 9: // STATE 2 - p101.pml:9 - [name!33,121] (0:0:0 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		if (q_len(now.name))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.name);
		sprintf(simtmp, "%d", 33); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 121); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.name, 0, 33, 121, 2);
		{ boq = now.name; };
		_m = 2; goto P999; /* 0 */
	case 10: // STATE 3 - p101.pml:10 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

